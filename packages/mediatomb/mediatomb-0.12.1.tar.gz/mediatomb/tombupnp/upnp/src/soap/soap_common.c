#ifdef HAVE_CONFIG_H
    #include "autoconfig.h"
#endif


#include "config.h"
#if EXCLUDE_SOAP == 0

#include "httpparser.h"
#include "sock.h"
#include "soaplib.h"



#endif // EXCLUDE_SOAP
