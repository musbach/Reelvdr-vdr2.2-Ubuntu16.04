 /****************************************************************************
 * Copyright (c) 2008-2010 Intel Corporation.
 *
 * DISTRIBUTABLE AS SAMPLE SOURCE SOFTWARE
 *
 * This Distributable As Sample Source Software is subject to the terms and
 * conditions of the Intel software License Agreement for the Intel(R) Media
 * Processor Software Development Kit.
 ***************************************************************************
 * File Name: flash_appdata_strings.h
 ***************************************************************************/
#ifndef _FLASH_APPDATA_STRINGS_H_
#define _FLASH_APPDATA_STRINGS_H_
#if 0
const char *g_szFlashType[] = {
	"NOR",
	"NAND",
};

const char *g_szDeviceType[] = {
	"CE3100",
	"CE4100",
	"CE5100",
};
#endif
#endif
