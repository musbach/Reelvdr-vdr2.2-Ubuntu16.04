/* include/version.h.  Generated from version.h.in by configure.  */
#define CONFIG_SND_VERSION "1.0.23"
#define CONFIG_SND_DATE ""
