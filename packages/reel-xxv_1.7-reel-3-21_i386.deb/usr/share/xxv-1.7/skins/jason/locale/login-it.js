/*
 * jason - Javascript based skin for xxv
 * Copyright(c) 2009-2010, Diego Pierotto
 * 
 * http://projects.vdr-developer.org/projects/xxv
 *
 * Italian translation by Diego Pierotto [ita.translations@tiscali.it]
 */

/* login.js */
Ext.LoginPanel.prototype.szTitle = "Connessione";
Ext.LoginPanel.prototype.szUser = "Nome utente";
Ext.LoginPanel.prototype.szPassword = "Password";
Ext.LoginPanel.prototype.szLogin = "Entra"';
Ext.LoginPanel.prototype.szFailed = "Connessione fallita!";
Ext.LoginPanel.prototype.szWarning = "Attenzione!";
Ext.LoginPanel.prototype.szUnreachable = "Server autenticazione non raggiungibile : ";
