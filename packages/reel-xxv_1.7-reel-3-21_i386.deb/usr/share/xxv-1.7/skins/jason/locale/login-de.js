/*
 * jason - Javascript based skin for xxv
 * Copyright(c) 2009-2012, anbr
 * 
 * http://projects.vdr-developer.org/projects/xxv
 *
 * German translation
 */

/* login.js */
Ext.LoginPanel.prototype.szTitle = 'Bitte anmelden';
Ext.LoginPanel.prototype.szUser = 'Anwender';
Ext.LoginPanel.prototype.szPassword = 'Passwort';
Ext.LoginPanel.prototype.szLogin = 'Anmelden';
Ext.LoginPanel.prototype.szFailed = 'Anmeldung fehlgeschlagen!';
Ext.LoginPanel.prototype.szWarning = 'Warnung!';
Ext.LoginPanel.prototype.szUnreachable = 'Server zur Authentifizierung ist nicht erreichtbar : ';
