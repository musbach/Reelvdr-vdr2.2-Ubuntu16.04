/*
 * jason - Javascript based skin for xxv
 * Copyright(c) 2009-2012, anbr
 * 
 * http://projects.vdr-developer.org/projects/xxv
 *
 * Template for translation
 */

/* login.js */
Ext.LoginPanel.prototype.szTitle = 'Please login';
Ext.LoginPanel.prototype.szUser = 'Username';
Ext.LoginPanel.prototype.szPassword = 'Password';
Ext.LoginPanel.prototype.szLogin = 'Login';
Ext.LoginPanel.prototype.szFailed = 'Login failed!';
Ext.LoginPanel.prototype.szWarning = 'Warning!';
Ext.LoginPanel.prototype.szUnreachable = 'Authentication server is unreachable : ';
