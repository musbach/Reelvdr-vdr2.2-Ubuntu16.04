#!/bin/sh
echo "/usr/sbin/IMDB-cover-search.pl \"$1\" > /dev/null 2>&1" | at now
echo "Movie cover search is being executed in the background."
