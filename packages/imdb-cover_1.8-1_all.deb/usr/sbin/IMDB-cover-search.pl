#!/usr/bin/perl
#########################################################################################
########			author : schlue					#########
#########################################################################################
#########################################################################################
########			history						#########
#########################################################################################
# 02.04.2012:	1.0 ( first version )							#
# 08.05.2012:	1.1									#
#		- multiple instances can run at the same time				#
#		- avoid white borders							#
#		- reduce black borders as much as possible				#
#		- first version which is distributed as deb				#
#		- changed search algorithm						#
#		- introduced vdr.override						#
# 24.11.2012:	- needs libwww-mechanize-perl						#
# 10.12.2012:	- changes due to new web layouts ...					#
# 16.12.2012:	- and again with cinefacts.de						#
# 06.10.2013:	- in case no results are found						#
# 11.10.2013:	- use autocheck = 0 instead of 1					#
# 10.11.2013:	- modified FindFilmMoviePilot due to changed web			#
#		  layout								#
#		- added checks for return values					#
#		- use imdb.com instead of imdb.de					#
#		- updated AGENT								#
# 14.12.2013:	1.5									#
#		- enhanced cinefact search						#
# 05.07.2015:	1.6									#
#		- needed to adapt nearly all parsing routine due to changes in		#
#		  web pages								#
# 13.09.2015:	1.7									#
#		- modified FindMoviePilot due to changed web layout			#
# XX.XX.XXXX:	- think to add http:77thetvdb.com					#
# 13.07.2016:	1.8									#
#		- to be addded: site:http://www.movies.ch/de/film/ $title		#
#		- may be use: http://www.covershut.com					#
#		- thetvdb.com makes only sense for series ( not yet implemented )	#
#		- modified FindMoviePilot due to changed web layout			#
#		- added amazon prime video covers					#
#		- disabled FilmCover side is offline					#
#		- updated FindFilmCinefacts ( now uses kino.de as both melted tog. )	#
#		- modified FindFilmIMDB due to changes in web layout			#
#########################################################################################

#########################################################################################
#											#
#				test cases						#
#											#
#########################################################################################
#	"Olympus Has Fallen - Die Welt in Gefahr"
#	"Django Unchained"


#########################################################################################
########			library section					#########
#########################################################################################
use strict;
use WWW::Mechanize;
use WWW::Mechanize::FormFiller;
use HTML::TokeParser;
use HTML::PullParser ();
use URI::Escape;
use LWP::Simple;
use Image::Magick;
use LWP::UserAgent;
use HTML::Entities;
use JSON;
use utf8;
use Encode;
no warnings "all";
use Data::Dumper;

$| = 1;


#########################################################################################
########			variable section				#########
#########################################################################################
my $file	= ();
my $film	= ();
my $title	= ();
my @title	= ();
my $success	= 0;
my $SUBTITLE	= ();
my $TITLE	= ();
my $REC		= ();
my $INFO	= ();
my $scale	= ();
my $url		= ();
my $IMDB	= 'http://imdb.com';
my $MOVIEPILOT	= 'http://www.moviepilot.de';
my $COVERLIB	= 'http://coverlib.com/';
my $AMAZON	= 'http://amazon.de';
my $DEBUG	= 0;
my $AGENT	= 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0';
my $CINEFACTSBASE = 'http://www.kino.de/';
my $CINEFACTS	  = $CINEFACTSBASE . 's/form_submit';
my @LANGUAGE	= qw( GER USA GBR );


#########################################################################################
########			main section					#########
#########################################################################################
$file  = '/tmp/' . $$ . '-cover.jpg';
$REC   = $ARGV[0];

if ( ! -d $REC || ! -w $REC )
{
	die( "Recording directory does not exist or is not writeable" );
}

if ( -e "$REC" . '/info.override' )
{
	# overrride can be used to manipulate the movies title and get the cover you want
	open( INFO, "<$REC" . '/info.override' ) || die "Not able to open $REC" . '/info.txt';
}
elsif ( -e "$REC" . '/info.txt' )
{
	# reel vdr 1.7 info information
	open( INFO, "<$REC" . '/info.txt' ) || die "Not able to open $REC" . '/info.txt';
}
elsif ( -e "$REC" . '/info.vdr' )
{
	# vdr 1.4 info information
	open( INFO, "<$REC" . '/info.vdr' ) || die "Not able to open $REC" . '/info.vdr';
}
elsif ( -e "$REC" . '/info' )
{
	# vdr 1.7 info information
	open( INFO, "<$REC" . '/info' ) || die "Not able to open $REC" . '/info';
}
else
{
	die( "info file does not exist" );
}

while ( !eof( INFO ) )
{
	chomp( $INFO = (<INFO>) );
	if ( $INFO =~ m/^T / )
	{
		$INFO =~ s/^T //;
		$TITLE = $INFO;
	}
	elsif ( $INFO =~ m/^S / )
	{
		$INFO =~ s/^S //;
		$SUBTITLE = $INFO;
	}
}
close( INFO );

if ( ( defined $SUBTITLE ) && ( $SUBTITLE ne '' ) )
{
	push @title, decode_utf8( $TITLE . ' - ' . $SUBTITLE );
}

push @title, decode_utf8( $TITLE );

if ( ( defined $SUBTITLE ) && ( $SUBTITLE ne '' ) )
{
	my $tmp = decode_utf8( $TITLE . ' - ' . $SUBTITLE );
	$tmp =~ s/\s+- [^-]+$//;
	push @title, $tmp;
}

my $tmp = decode_utf8( $TITLE );
$tmp =~ s/\s+- [^-]+$//;
push @title, $tmp;

foreach $title ( @title )
{
	$title =~ s/\s*-\s*Director.*?Cut\s*$//i;
	$title =~ s/\s*-\s*Extended\s*Version\s*$//i;
	$title =~ s/\(.+\)//;
	$title =~ s/\s*$//;

	if ( $DEBUG ne 0 )
	{
		print( "$title\n" )
	}

	( $success, $film ) = FindFilmAmazonVideo( $title );

	if ( ! $success )
	{
		( $success, $film ) = FindFilmMoviePilot( $title );
	}

#       ! disabled because side is down
#	if ( ! $success )
#	{
#		( $success, $film ) = FindFilmCover( $title );
#	}
#       ! disabled because side is down

	if ( ! $success )
	{
		( $success, $film ) = FindFilmIMDB( $title );
	}

	if ( ! $success )
	{
		( $success, $film ) = FindFilmCinefacts( $title );
	}

	if ( $success )
	{
		last;
	}
}


if ( $DEBUG ne 0 )
{
	print( "success: $success film: $film\n" );
}

if ( ! defined $film || !$success )
{
	die "Movie and/or cover not found";
}


my $cover = $film;
getstore($cover,$file);

if ( $DEBUG ne 0 )
{
	print( $file, "\n" );
}

$cover = Image::Magick->new;
$cover->read( $file );

#get cover dimension
my $width = $cover->Get('width');
my $height= $cover->Get('height');

if ( $success ne 'Front' )
{
	$cover->Crop(geometry=>$width/2 . 'x' . $height . '+' . $width/2*1.05 . '-0');
	$width = $cover->Get('width');
	$height= $cover->Get('height');
}


#check for longest side
if ( $height >= $width )
{
	# recalc dimensons based on height
	$scale = $height / 128;
	$height= 128;
	$width = sprintf( "%s", int( $width / $scale ));
}
else
{
	# recalc dimensons based on width
	$scale = $width / 126;
	$width= 126;
	$height = sprintf( "%s", int( $height / $scale ));
}

$cover->Set( Gravity => 'Center' );
$cover->Resize( geometry => $width .'x'. $height, background => 'black' );
$cover->Extent( geometry => $width .'x'. $height, background => 'black' );
$file =~ s/cover.jpg/preview_vdr.png/;
$file =  $REC . '/preview_vdr.png';

$cover->Write( $file );


#####################################################################
#####			access IMDB				#####
#####################################################################
sub FindFilmIMDB
{
	my $title = shift;
	my $success = 0;

	if ( $DEBUG ne 0 )
	{
		print( "I am in FindFilmDB\n " );
	}

	my $agent = WWW::Mechanize->new( autocheck => 0 );
	my $formfiller = WWW::Mechanize::FormFiller->new();
	$agent->env_proxy();
	$agent->agent( $AGENT );
	my $response = $agent->get( $IMDB );

	if ( $response->is_success )
	{
		$agent->form_number(1) if $agent->forms and scalar @{$agent->forms};
		{ local $^W; $agent->current_form->value( 'q', "$title" ); };
		{ local $^W; $agent->current_form->value( 's', 'Titles' ); };

		$response = $agent->submit();

		if ( $response->is_success )
		{
			my $result = $agent->content();
			if ( $result =~ m/No results found for/igs )
			{
				return( 0, undef );
			}

			if ( $result =~ m/Exact title matches/ )
			{
				$response = $agent->follow_link( text => 'Exact title matches' );
			}

			if ( ( defined $response ) && ( $response->is_success ) )
			{
				$result = $agent->content();;

				if ( $result =~ m/No results found for/igs )
				{
					return( 0, undef );
				}

				if ( $result =~ m/<table class="findList">/gs )
				{
					$result =~ s!.*<table class="findList">!!gs;
					$result =~ s!</table.*!!gs;

					my @lines = split( /<\/tr><tr/,$result );

					my $search = ();
					for ( my $loop = 0; $loop < scalar( @lines ); $loop++ )
					{
						if ( $lines[ $loop ] !~ /nopicture/ )
						{
							$search = $lines[ $loop ];
							$search =~ s!.*/title/!/title/!;
							$search =~ s!".*!!;
							$search =~ s!\n!!;

							$response = $agent->get( $IMDB . $search );
							if ( $response->is_success )
							{
								$result = $agent->content();
								@lines = split( /\n/,$result );

								@lines = grep( /href="\/title\/tt[0-9]+\/media.*ref_=tt_ov_i/, @lines );

								$result = $lines[0];
								$result =~ s#"##g;
								$result =~ s#.*a href=##;

								$response = $agent->get( $IMDB . $result );
								if ( $response->is_success )
								{
									$result = $agent->content();

									@lines = split( /\n/,$result );
									@lines = grep( /og:image/, @lines );
									$result = $lines[0];
									$result =~ s!.*content='!!;
									$result =~ s!'.*!!;

									if ( $result =~ m!^http[s]*://! )
									{
										return( 'Front', $result );
									}
									else
									{
										return( 0, undef );
									}
								}
							}
						}
					}
				}
				elsif ( $result =~ m!title-overview/primary/images! )
				{
					my @lines = split( /\n/,$result );

					@lines = grep( /title-overview\/primary\/images/, @lines );
					$result = $lines[0];
					$result =~ s!.*href="!!;
					$result =~ s!".*!!;

					$response = $agent->get( $IMDB . $result );
					if ( $response->is_success )
					{
						$result = $agent->content();
						@lines = split( /\n/,$result );
						@lines = grep( /og:image/, @lines );
						$result = $lines[0];
						$result =~ s!.*href="!!;
						$result =~ s!".*!!;

						if ( $result =~ m!^http://! )
						{
							return( 'Front', $result );
						}
						else
						{
							return( 0, undef );

						}
					}
				}
			}
		}
	}
	return( 0, undef );
}


#####################################################################
#####			access DBs				#####
#####################################################################
sub FindFilmAmazonVideo
{
	my $title = shift;
	my $success = 0;
	my $response = ();

	if ( $DEBUG ne 0 )
	{
		print( "I am in FindFilmAmazonVideo\n " );
	}

	# create agent
	my $agent = WWW::Mechanize->new( autocheck => 1 );
	my $formfiller = WWW::Mechanize::FormFiller->new();
	$agent->env_proxy();

	# initial amazon page download
	$response = $agent->get( $AMAZON );
	if ( $response->is_success )
	{
		# fill form
		$agent->form_number(1) if $agent->forms and scalar @{$agent->forms};
		$formfiller->add_filler( 'url' => Fixed => 'search-alias=instant-video' );
		$formfiller->add_filler( 'field-keywords' => Fixed => $title );
		{ local $^W; $formfiller->fill_form($agent->current_form); };

		# submit
		$response = $agent->submit();

		if ( $response->is_success )
		{
			my $result = $agent->content();

			# parse result and check for title
			my @lines = split( /\n/,$result );
			@lines = grep( /title=\"$title\"/i, @lines );

			# is title we search for available ?
			if ( ( defined $lines[0] ) && ( $lines[0] ne "" ) )
			{
				# yes, continue link extraction
				my $link = $lines[0];
				$link =~ s!\"><h2 data-attribute=.*!!;
				$link =~ s!.*href=.!!;

				# follow link to detailed description page ( which contains the cover )
				$response = $agent->get( $link );
				if ( $response->is_success )
				{
					# extract link
					$result = $agent->content();
					@lines = split( /\n/,$result );
					@lines = grep( /og:image/, @lines );

					if ( ( defined $lines[0] ) && ( $lines[0] ne "" ) )
					{
						$link = $lines[0];
						$link =~ s/.*content="//;
						$link =~ s/jpg.*/jpg/;

						# if variable contains a link return the result
						if ( $link =~ m!^http[s]*://.*jpg!i )
						{
							return( 'Front', $link );
						}
					}
				}
			}
		}
 	}
	# no result
	return( 0, undef );
}


#####################################################################
#####			access DBs				#####
#####################################################################
sub FindFilmMoviePilot
{
	my $title = shift;
	my $success = 0;
	my $response = ();

	if ( $DEBUG ne 0 )
	{
		print( "I am in FindFilmMoviePilot\n " );
	}

	my $agent = WWW::Mechanize->new( autocheck => 1 );
	my $formfiller = WWW::Mechanize::FormFiller->new();
	$agent->env_proxy();
	$agent->agent( $AGENT );

	$response = $agent->get( "$MOVIEPILOT" );
	if ( $response->is_success )
	{
		$response = $agent->get( $MOVIEPILOT . '/api/search?type=suggest&&q=' . $title );

		if ( $response->is_success )
		{
			if (( $agent->content() =~ m/Keine Treffer für deine Suchanfrage in dieser Kategorie/gsi )||( $agent->content() =~ m/Wir haben leider keinen Treffer f.*r deine Suchanfrage gefunden/gsi ))
			{
				return( 0, undef );
			}

			my $data = JSON->new->utf8(1)->decode( $agent->content() );

			if (( defined $$data[0]->{title} ) && ( defined $$data[0]->{url} ))
			{
				if ( $$data[0]->{title} !~ m/$title/gsi )
				{
					print( $$data[0]->{title}, "\n" );
					print( "no match\n\n\n" );
					return( 0, undef );
				}
			}

			$response = $agent->get( $$data[0]->{url} );
			if ( $response->is_success )
			{
				my @lines = split( /\n/,$agent->content() );
				@lines = grep( /div style=\"background-image: url/, @lines );
				@lines = grep( /ass=\"poster\" itemprop=\"contentUrl\"/, @lines );

				my $result = $lines[0];

				if (( $result =~ m/no_poster/ ) || ( $result eq "" ) )
				{
					return( 0, undef );
				}

				$result =~ s!.*"http!http!;
				$result =~ s!".*!!;

				if ( $result =~ m!^http://! )
				{
					if ( $result =~ m!http.*http! )
					{
						$result =~ s!http.*http!http!;
					}
					return( 'Front', $result );
				}
				else
				{
					return( 0, undef );
				}
			}
		}
	}
	return( 0, undef );
}


#####################################################################
#####			build cover collection			#####
#####################################################################
sub AddTo
{
	my ( $DATA, $COVERNR, $INFO ) = @_;

	# 'elementTyp' => 'Front',
	# 'Items' => '1',
	# 'Res' => '3.211 x 2.161px',
	# 'Date' => '2007-11-13 01:11',
	# 'Archivist' => 'garyd138',
	# 'Download' => 'http://coverlib.com//Download/721890/Dr-House-House_M-D-Season_1-Front-.JPG',
	# 'Views' => '12.387 times',
	# 'Filesize' => '2,67 MB',
	# 'Size' => '2,67 MB'

	$$COVERNR++;
	$$DATA{COVER}[ $$COVERNR ]	= ();
	$$DATA{URL}[ $$COVERNR ]	= ();
	$$DATA{RESOLUTION}[ $$COVERNR ]	= ();
	$$DATA{SIZE}[ $$COVERNR ]	= ();
	$$DATA{DOWNLOADS}[ $$COVERNR ]	= ();

	$$DATA{URL}[ $$COVERNR ]	= $$INFO{Download};
	$$DATA{URL}[ $$COVERNR ]	=~ s#//Down#/Down#;

	$$DATA{DOWNLOADS}[ $$COVERNR ]	= $$INFO{Views};
	$$DATA{DOWNLOADS}[ $$COVERNR ]	=~ s/ .*//;

	$$DATA{RESOLUTION}[ $$COVERNR ]	= $$INFO{Res};
	$$DATA{SIZE}[ $$COVERNR ]	= $$INFO{Filesize};
	$$DATA{COVER}[ $$COVERNR ]	= $$INFO{elementTyp};
	$$DATA{LANGUAGE}[ $$COVERNR ]	= $$INFO{Language};
}


#####################################################################
#####			access cover				#####
#####################################################################
sub FindFilmCover
{
	my $title	= shift;
	my $success	= 0;
	my $response	= ();
	my $STATUS	= -1;
	my %INFO	= ();

	if ( $DEBUG ne 0 )
	{
		print( "I am in FindFilmCover\n " );
	}

	my $agent = WWW::Mechanize->new( autocheck => 0 );
	my $formfiller = WWW::Mechanize::FormFiller->new();
	$agent->env_proxy();
	$agent->agent( $AGENT );

	$response = $agent->get( $COVERLIB );
	if ( $response->is_success )
	{

		foreach my $cover ( qw/26 27 6 3 1 11 17/ )
		{
			#	$agent->form_number(3);
			#	{ local $^W; $agent->current_form->value('SearchString', "$title" ); };
			#	{ local $^W; $agent->current_form->value('StringMode', 'Title is Searchstring' ); };

			#	{ local $^W; $agent->untick( 'SektionID-2',  'Yes' ) };	#Audio-CD
			#	{ local $^W; $agent->untick( 'SektionID-10', 'Yes' ) };	#Audio-DVD
			#	{ local $^W; $agent->untick( 'SektionID-18', 'Yes' ) };	#Audio-Kassette
			#	{ local $^W; $agent->untick( 'SektionID-5',  'Yes' ) };	#Audio-Maxi-CD
			#	{ local $^W; $agent->untick( 'SektionID-19', 'Yes' ) };	#Audio-SVCD
			#	{ local $^W; $agent->untick( 'SektionID-16', 'Yes' ) };	#Audio-VHS
			#	{ local $^W; $agent->untick( 'SektionID-33', 'Yes' ) };	#Blu-ray-Audio
			#	{ local $^W; $agent->untick( 'SektionID-21', 'Yes' ) };	#Gamecube
			#	{ local $^W; $agent->untick( 'SektionID-28', 'Yes' ) };	#GBA
			#	{ local $^W; $agent->untick( 'SektionID-12', 'Yes' ) };	#Hörspiele
			#	{ local $^W; $agent->untick( 'SektionID-31', 'Yes' ) };	#iTunes: Filme
			#	{ local $^W; $agent->untick( 'SektionID-29', 'Yes' ) };	#NDS
			#	{ local $^W; $agent->untick( 'SektionID-4',  'Yes' ) };	#PC-Games
			#	{ local $^W; $agent->untick( 'SektionID-14', 'Yes' ) };	#PC-Programme
			#	{ local $^W; $agent->untick( 'SektionID-8',  'Yes' ) };	#PS1
			#	{ local $^W; $agent->untick( 'SektionID-7',  'Yes' ) };	#PS2
			#	{ local $^W; $agent->untick( 'SektionID-25', 'Yes' ) };	#PS3
			#	{ local $^W; $agent->untick( 'SektionID-22', 'Yes' ) };	#UMD
			#	{ local $^W; $agent->untick( 'SektionID-11', 'Yes' ) };	#Video-VHS
			#	{ local $^W; $agent->untick( 'SektionID-13', 'Yes' ) };	#Vinyl
			#	{ local $^W; $agent->untick( 'SektionID-24', 'Yes' ) };	#Wii
			#	{ local $^W; $agent->untick( 'SektionID-20', 'Yes' ) };	#X-Box
			#	{ local $^W; $agent->untick( 'SektionID-23', 'Yes' ) };	#X-Box 360
			#	{ local $^W; $agent->untick( 'SektionID-9',  'Yes' ) };	#xxx

			#	{ local $^W; $agent->tick( 'SektionID-26', 'Yes', 'true' ) };	#Blu-ray
			#	{ local $^W; $agent->tick( 'SektionID-17', 'Yes', 'true' ) };	#Dokumentation
			#	{ local $^W; $agent->tick( 'SektionID-27', 'Yes', 'true' ) };	#HD-DVD
			#	{ local $^W; $agent->tick( 'SektionID-6', 'Yes',  'true' ) };	#Serien
			#	{ local $^W; $agent->tick( 'SektionID-3', 'Yes',  'true' ) };	#Video-DVD
			#	{ local $^W; $agent->tick( 'SektionID-1', 'Yes',  'true' ) };	#Video-SVCD
			#	{ local $^W; $agent->tick( 'SektionID-11', 'Yes', 'true' ) };	#Video-VHS

			#	{ local $^W; $agent->tick( 'Language-1', 'Yes', 'true' ) };	#German

			$response = $agent->get( $COVERLIB . 'search/?Sektion=' . $cover . '&q=' . $title );

			if ( $response->is_success )
			{
				my $result = $agent->content();

				if ( ( $result =~ m/Search Failed/i ) || ( $result =~ m/Sorry we could not find anything that matches against:/i ) || ( $result =~ m/Keine Ergebnisse gefunden/i ) || ( $result =~ m/- No results found, sorry. Please try again-/i ) )
				{
					next;
				}

				my %DATA = ();
				my $COVERNR = -1;

				do
				{
					# get pointer to next page ( if there is any )
					my @lines = split( /[\n,\t]/,$result );
					@lines = grep( /glyphicon-chevron-right/, @lines );
					my $next = $lines[0];

					# extract href ( of pointer )
					if ( $next =~ m/href=/ )
					{
						$next =~ s/.*href=\"//;
						$next =~ s/\".*//;
					}
					else
					{
						# no link to next page
						$next	= 0;
					}

					# get links to covers on current page
					@lines = split( /[\n,\t]/,$agent->content() );
					@lines = grep( /data-href=/, @lines );

					foreach my $link ( @lines )
					{
						$link =~ s!.*data-href=\"!!;
						$link =~ s!\".*!!;
						$link =~ s!^/!!;

						if ( $DEBUG )
						{
							print( $COVERLIB . $link, "\n" );
						}

						# download page to cover of movie
						$response = $agent->get( $COVERLIB . $link );

						# and parse in case the page was loaded
						if ( $response->is_success )
						{
							$result = $agent->content();

							my @COVER_TAGS = qw(div h3 span a strong p);

							my $p = HTML::PullParser->new(	doc		=> $result,
											start		=> 'tag, attr',
											end		=> 'tag',
											text		=> '@{text}',
											report_tags	=> \@COVER_TAGS,
										)  || die "$!";


							panelheading:
							while ( defined( my $t = $p->get_token ) )
							{
								# find 'pnael-heading'
								next unless ( ( ref $t ) && ( $t->[0] eq 'div' ) && ( defined( $t->[1] ) ) && ( $t->[1]->{class} eq 'panel-heading' ) );

								# find <p>
								while ( defined( $t = $p->get_token ) )
								{
									next unless ( ( ref $t ) && ( $t->[0] eq 'p' ) );

									# find text entries ( not a ref )
									GetText:
									while ( defined( $t = $p->get_token ) )
									{
										if ( ! ref $t )
										{
											chomp( $t );
											$t =~ s/\r?\n//sg;
											$t =~ s/^[ 	]*//;
											$t =~ s/[ 	]*$//;
											$t =~ s/:$//;

											my $key = $t;

											while ( defined( $t = $p->get_token ) )
											{
												if ( ! ref $t )
												{
													chomp( $t );
													$t =~ s/\r?\n//sg;
													$t =~ s/^[ 	]*//;
													$t =~ s/[ 	]*$//;
													$t =~ s/:$//;

													my $value = $t;

													$INFO{ $key } = $value;

													if ( !defined( $INFO{Size}) )
													{
														next GetText;
													}
													else
													{
														while ( defined( $t = $p->get_token ) )
														{
															next unless ( ( ref $t ) && ( $t->[0] eq 'span' ) && ( defined( $t->[1] ) ) && ( $t->[1]->{class} eq 'label label-info' ) );
															while ( defined( $t = $p->get_token ) )
															{
																if ( ! ref $t )
																{
																	chomp( $t );
																	$t =~ s/\r?\n//sg;
																	$t =~ s/^[ 	]*//;
																	$t =~ s/[ 	]*$//;
																	$t =~ s/:$//;

																	$INFO{Language} = $t;

																	last panelheading;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}

							Thumbnail:
							while ( defined( my $t = $p->get_token ) )
							{
								# find <div class="thumbnail">
								if ( ( ref $t ) && ( $t->[0] eq 'div' ) && ( defined( $t->[1] ) ) && ( $t->[1]->{class} eq 'clearfix' ) )
								{
									last Thumbnail;
								}

								next unless ( ( ref $t ) && ( $t->[0] eq 'div' ) && ( defined( $t->[1] ) ) && ( $t->[1]->{class} eq 'thumbnail' ) );

								GetType:
								while ( defined( $t = $p->get_token ) )
								{
									next unless ( ( ref $t ) && ( $t->[0] eq 'a' ) && ( defined( $t->[1] ) ) && ( $t->[1]->{class} eq 'gallerytwo-item' ) );
									$INFO{Download} = $COVERLIB . $t->[1]->{href};

									while ( defined( $t = $p->get_token ) )
									{
										next unless ( ( ref $t ) && ( $t->[0] eq 'h3' ) && ( defined( $t->[1] ) ) && ( $t->[1]->{class} eq 'elementTyp' ) );

										# find text entries ( not a ref )
										while ( defined( $t = $p->get_token ) )
										{
											if ( ! ref $t )
											{
												chomp( $t );
												$t =~ s/\r?\n//sg;
												$t =~ s/^[ 	]*//;
												$t =~ s/[ 	]*$//;
												$t =~ s/:$//;

												$INFO{elementTyp} = $t;

												# find <p>
												while ( defined( $t = $p->get_token ) )
												{
													next unless ( ( ref $t ) && ( $t->[0] eq 'p' ) );

													GetStrong:
													while ( defined( my $t = $p->get_token ) )
													{
														next unless ( ( ref $t ) && ( $t->[0] eq 'strong' ) );

														while ( defined( $t = $p->get_token ) )
														{
															if ( ! ref $t )
															{
																chomp( $t );
																$t =~ s/\r?\n//sg;
																$t =~ s/^[ 	]*//;
																$t =~ s/[ 	]*$//;
																$t =~ s/:$//;

																my $key = $t;

																while ( defined( $t = $p->get_token ) )
																{
																	if ( ! ref $t )
																	{
																		chomp( $t );
																		$t =~ s/\r?\n//sg;
																		$t =~ s/^[ 	]*//;
																		$t =~ s/[ 	]*$//;
																		$t =~ s/:$//;

																		my $value = $t;

																		$INFO{ $key } = $value;

																		if ( !defined( $INFO{Res}) )
																		{
																			next GetStrong;
																		}
																		else
																		{
																			AddTo( \%DATA, \$COVERNR, \%INFO );
																			%INFO = ();
																			next Thumbnail;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}

					if ( $next )
					{
						$response = $agent->get( $COVERLIB . 'search/' . $next );

						if ( $response->is_success )
						{
							$result = $agent->content();
						}
						else
						{
							$result = 0;
						}
					}
					else
					{
						$result = 0;
					}
				} while ( $result );

				my $downloads;
				my $thisloop;
				my $thistype;

				if ( ! defined ( $DATA{COVER} ) )
				{
					return( 0, undef );		#schlue: 06.10.2013: in case no results are found
				}

				foreach my $language ( @LANGUAGE )
				{
					# Front Cover Booklet
					foreach my $key ( qw/Front Cover Booklet/ )
					{
						$downloads = 0;
						$thisloop = -1;

						for ( my $loop = 0; $loop < scalar( @{ $DATA{COVER} } ); $loop++ )
						{
							if ( ( $DATA{COVER}[ $loop ] =~ m/$key/ ) && ( $DATA{LANGUAGE}[ $loop ] =~ m/$language/ ) )
							{
								if ( $DATA{DOWNLOADS}[ $loop ] > $downloads )
								{
									$downloads = $DATA{DOWNLOADS}[ $loop ];
									$thisloop= $loop;
									$thistype= $key;
								}
							}
						}

						if ( $thisloop > -1 )
						{
							last;
						}
					}
				}

				if ( $thisloop > -1 )
				{
					$DATA{URL}[ $thisloop ] =~ s!^\.!!;
					return( $thistype, $DATA{URL}[ $thisloop ] );
				}
			}
		}
	}
	return( 0, undef );
}


#####################################################################
#####			access cinefacts			#####
#####			now called kino.de			#####
#####################################################################
sub FindFilmCinefacts
{
	my $mustmatch = shift;
	my $title = uri_escape( $mustmatch );
	$mustmatch =~ s#[ ]-.*##;
	my $success = 0;
	my $response = ();
	my $STATUS = -1;

	if ( $DEBUG ne 0 )
	{
		print( "I am searching for $mustmatch in FindFilmKino\n " );
	}

	my $agent = WWW::Mechanize->new( autocheck => 0 );
	my $formfiller = WWW::Mechanize::FormFiller->new();
	$agent->env_proxy();
	$agent->agent( $AGENT );

	my $ua = LWP::UserAgent->new;
	$ua->timeout(10);
	$ua->agent( $AGENT );

	$response = $agent->post( $CINEFACTS, [searchterm => $title, submit => '']);
	if ( $response->is_success )
	{
#	<ol class=\"search-result-list figure\"><li data-score=\"11.6320\"><figure class=\"item-figure \"><img src=\"http://media1.kino.de/2015/08/django-unchained-2012-filmplakat-rcm260x370u.jpg\" alt=\"\" /><figcaption><dl class=\"item-name\"><dt><a href=\"http://www.kino.de/film/django-unchained-2012/\"><span class=\"movie-name\">Django Unchained</span></a></dt></dl></figcaption></figure></li><li data-score=\"1.5609\"><figure class=\"item-figure \"><img src=\"http://media1.kino.de/2015/08/sweetwater-rache-ist-s-2013-film-rcm260x370u.jpg\" alt=\"\" /><figcaption><dl class=\"item-name\"><dt><a href=\"http://www.kino.de/film/sweetwater-rache-ist-suess-2013/\"><span class=\"movie-name\">Sweetwater - Rache ist s\x{fc}\x{df}</span></a></dt></dl></figcaption></figure></li><li data-score=\"1.4086\"><figure class=\"item-figure \"><img src=\"http://media2.kino.de/2015/08/yellow-rock-2011-film-rcm260x370u.jpg\" alt=\"\" /><figcaption><dl class=\"item-name\"><dt><a href=\"http://www.kino.de/film/yellow-rock-2011/\"><span class=\"movie-name\">Yellow Rock</span></a></dt></dl></figcaption></figure></li><li data-score=\"1.0406\"><figure class=\"item-figure \"><img src=\"http://media2.kino.de/2016/07/the-hateful-8-2015-filmplakat-rcm260x370u.jpg\" alt=\"\" /><figcaption><dl class=\"item-name\"><dt><a href=\"http://www.kino.de/film/the-hateful-eight/\"><span class=\"movie-name\">The Hateful 8</span></a></dt></dl></figcaption></figure></li></ol>                                                                                   <div class=\"more\"><a href=\"http://www.kino.de/se/django%2Bunchained/?sp_search_filter=movie\">Alle Filme</a></div>


		if ( $agent->content() =~ m/lieferte keine Treffer/ )
		{
			return( 0, undef );
		}

		my @lines = split( /\n/,$agent->content() );
		@lines = grep( /search-result-list/, @lines );
		@lines = grep( /movie-name/, @lines );
		@lines = grep( /$mustmatch/i, @lines );

		my $link = $lines[0];
		$link =~ s!"[ ]*alt=.*!!;
		$link =~ s!.*"!!;

		if ( ( $link =~ m!^http[s]*://! ) && ( $link =~ m!-filmplakat-! ) )
		{
			return( 'Front', $link );
		}
	}
	return( 0, undef );
}
