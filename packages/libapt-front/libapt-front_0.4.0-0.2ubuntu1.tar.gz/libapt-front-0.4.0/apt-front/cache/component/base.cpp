#include <apt-front/cache/component/base.h>
