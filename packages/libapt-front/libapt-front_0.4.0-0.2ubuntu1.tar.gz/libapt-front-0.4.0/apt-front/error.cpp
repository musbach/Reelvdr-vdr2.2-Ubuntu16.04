#include "error.h"

namespace aptFront {
   GlobalError *getGlobalError()  {
      return _error;
   }
}
