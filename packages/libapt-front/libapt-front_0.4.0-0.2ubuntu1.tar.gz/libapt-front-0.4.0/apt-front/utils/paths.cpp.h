#define DEBTAGS_DB_DIR "/var/lib/debtags"
#define DEBTAGSDOWNLOADDIR "/var/cache/debtags"
#define DEBTAGSCONFIGDIR "/etc/debtags"
#define DEBTAGSDATADIR "/usr/share/debtags"
