#!/bin/sh -e

# Build the build system
autopoint
autoreconf -i
