﻿pref("extensions.abhere2@moztw.org.description", "chrome://abhere2/locale/abhere2.properties");

pref("abhere2.position.abhere", 1);
pref("abhere2.position.optabs", 2);

pref("abhere2.clicking.left"  , 0);
pref("abhere2.clicking.middle", 1);
pref("abhere2.clicking.right" , 2);

pref("abhere2.starUI.row.name"               , true);
pref("abhere2.starUI.row.folderPicker"       , true);
pref("abhere2.starUI.row.tags"               , true);
pref("abhere2.starUI.row.description"        , true);
pref("abhere2.starUI.row.keyword"            , true);
pref("abhere2.starUI.row.location"           , true);
pref("abhere2.starUI.row.loadInSidebar"      , true);
pref("abhere2.starUI.row.feedLocation"       , true);
pref("abhere2.starUI.row.siteLocation"       , true);
pref("abhere2.starUI.expand.folderRow"       , true);
pref("abhere2.starUI.expand.tagsRow"         , true);
pref("abhere2.starUI.height.folderTree"      , 150);
pref("abhere2.starUI.height.tagsSelector"    , 75);
pref("abhere2.starUI.height.descriptionField", 50);
pref("abhere2.starUI.width"                  , 350);

pref("abhere2.bmProp.expand.folderRow"   , false);
pref("abhere2.bmProp.expand.tagsRow"     , false);
pref("abhere2.bmProp.height.folderTree"  , 150);
pref("abhere2.bmProp.height.tagsSelector", 75);
pref("abhere2.bmProp.width"              , 350);

pref("abhere2.starUI.clicking.left"      , 0);
pref("abhere2.starUI.clicking.middle"    , 9);
pref("abhere2.starUI.clicking.right"     , 8);

pref("abhere2.bmsmenu.addbmhere", false);
pref("abhere2.bmsmenu.bmcurpage", true);
pref("abhere2.bmsmenu.bmalltabs", true);
pref("abhere2.bmsmenu.bmlibrary", true);
pref("abhere2.bmsmenu.subscribe", true);
pref("abhere2.context.addbmhere", true);

pref("abhere2.misc.insertTop"   , true);
pref("abhere2.misc.tagsInline"  , true);

pref("abhere2.folder.insideFolder", false);
pref("abhere2.folder.middleClick" , 0);

pref("abhere2.folderId.bookmark", 0);
pref("abhere2.folderId.livemark", 0);
pref("abhere2.folderId.unsorted", 0);
