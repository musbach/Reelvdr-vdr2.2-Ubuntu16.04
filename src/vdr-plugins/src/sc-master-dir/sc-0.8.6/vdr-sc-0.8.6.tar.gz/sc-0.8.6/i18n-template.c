/* 
 * Auto generated file, do not edit
 * Will be overwritten/deleted without warning
 * 
 * Edit the .po files if you want to update translations!!
 */

#include "i18n.h"

#if VDRVERSNUM < 10507

const tI18nPhrase ScPhrases[] = {
// START I18N
// END I18N
  { NULL }
  };

#endif
