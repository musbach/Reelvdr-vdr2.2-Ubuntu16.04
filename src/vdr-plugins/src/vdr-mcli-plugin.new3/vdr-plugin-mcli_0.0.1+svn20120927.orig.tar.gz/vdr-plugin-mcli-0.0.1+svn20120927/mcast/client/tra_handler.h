/*
 * (c) BayCom GmbH, http://www.baycom.de, info@baycom.de
 *
 * See the COPYING file for copyright information and
 * how to reach the author.
 *
 */

DLL_SYMBOL tra_info_t *tra_get_list(void);
int handle_tra(tra_info_t *tra_info);
