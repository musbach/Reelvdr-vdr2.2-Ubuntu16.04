/*
 * (c) BayCom GmbH, http://www.baycom.de, info@baycom.de
 *
 * See the COPYING file for copyright information and
 * how to reach the author.
 *
 */

DLL_SYMBOL int mld_client_init (char *intf);
DLL_SYMBOL void mld_client_exit (void);

