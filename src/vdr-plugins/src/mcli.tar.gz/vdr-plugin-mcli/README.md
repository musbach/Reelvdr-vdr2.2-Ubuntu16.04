vdr-plugin-mcli
===============
This is a "plugin" for the Video Disk Recorder (VDR) to access DVB-streams
produced by the NetCeiver-hardware.

Project's homepage:
http://www.baycom.de/hardware/netceiver/

Latest version available via SVN at:
https://svn.baycom.de/repos/vdr-mcli-plugin/

The vdr-plugin, mcli-library and associated tools&drivers
except netcv2dvbip are
Copyright (C) 2007-2010 by BayCom GmbH <info@baycom.de>

netcv2dvbip is 
Copyright (C) 2010 by Christian Cier-Zniewski <c.cier@gmx.de>

------------------------------------------------------------------

The mcli-library (libmcli.so) and all tools (including netcv2dvbip) 
are covered by the GNU LESSER GENERAL PUBLIC LICENSE (LGPL), version 2.1:

This library and all tools are free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License version
2.1 as published by the Free Software Foundation.

This library and all tools are distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

------------------------------------------------------------------

The vdr-plugin and associated tools are covered by the
GNU GENERAL PUBLIC LICENSE (GPL), version 2:

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License version 2 as published by
the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 51
Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.


To properly integrate the mcli plugin into your VDR please apply these two
patches:

vdr-1.6.0-altmenuaction.patch (allows CAM messages to be displayed)
vdr-1.6.0-intcamdevices.patch (enables selection of encrypted channels
                               without local CI stack).
 
