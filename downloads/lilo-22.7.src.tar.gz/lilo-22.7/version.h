/* version.h   */

#ifndef VERSION_H
#define VERSION_H
			/* retail */
#define VERSION_MAJOR 22
#define VERSION_MINOR 7
#define VERSION_EDIT  ""
#define VERSION_DATE "12-Apr-2005"

#endif
