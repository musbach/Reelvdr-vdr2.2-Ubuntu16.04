/* A Bison parser, made by GNU Bison 1.875d.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUM_TOK = 258,
     G_TOK = 259,
     S_TOK = 260,
     ID_TOK = 261,
     ANGLE_TOK = 262,
     AUDIO_TOK = 263,
     BREAK_TOK = 264,
     BUTTON_TOK = 265,
     CALL_TOK = 266,
     CELL_TOK = 267,
     CHAPTER_TOK = 268,
     CLOSEBRACE_TOK = 269,
     CLOSEPAREN_TOK = 270,
     COUNTER_TOK = 271,
     ELSE_TOK = 272,
     ENTRY_TOK = 273,
     EXIT_TOK = 274,
     FPC_TOK = 275,
     GOTO_TOK = 276,
     IF_TOK = 277,
     JUMP_TOK = 278,
     MENU_TOK = 279,
     NEXT_TOK = 280,
     OPENBRACE_TOK = 281,
     OPENPAREN_TOK = 282,
     PREV_TOK = 283,
     PROGRAM_TOK = 284,
     PTT_TOK = 285,
     REGION_TOK = 286,
     RESUME_TOK = 287,
     RND_TOK = 288,
     ROOT_TOK = 289,
     SET_TOK = 290,
     SUBTITLE_TOK = 291,
     TAIL_TOK = 292,
     TITLE_TOK = 293,
     TITLESET_TOK = 294,
     TOP_TOK = 295,
     VMGM_TOK = 296,
     BOR_TOK = 297,
     LOR_TOK = 298,
     XOR_TOK = 299,
     _OR_TOK = 300,
     BAND_TOK = 301,
     LAND_TOK = 302,
     _AND_TOK = 303,
     NOT_TOK = 304,
     NE_TOK = 305,
     EQ_TOK = 306,
     LT_TOK = 307,
     LE_TOK = 308,
     GT_TOK = 309,
     GE_TOK = 310,
     SUB_TOK = 311,
     ADD_TOK = 312,
     MOD_TOK = 313,
     DIV_TOK = 314,
     MUL_TOK = 315,
     ADDSET_TOK = 316,
     SUBSET_TOK = 317,
     MULSET_TOK = 318,
     DIVSET_TOK = 319,
     MODSET_TOK = 320,
     ANDSET_TOK = 321,
     ORSET_TOK = 322,
     XORSET_TOK = 323,
     SEMICOLON_TOK = 324,
     COLON_TOK = 325,
     ERROR_TOK = 326
   };
#endif
#define NUM_TOK 258
#define G_TOK 259
#define S_TOK 260
#define ID_TOK 261
#define ANGLE_TOK 262
#define AUDIO_TOK 263
#define BREAK_TOK 264
#define BUTTON_TOK 265
#define CALL_TOK 266
#define CELL_TOK 267
#define CHAPTER_TOK 268
#define CLOSEBRACE_TOK 269
#define CLOSEPAREN_TOK 270
#define COUNTER_TOK 271
#define ELSE_TOK 272
#define ENTRY_TOK 273
#define EXIT_TOK 274
#define FPC_TOK 275
#define GOTO_TOK 276
#define IF_TOK 277
#define JUMP_TOK 278
#define MENU_TOK 279
#define NEXT_TOK 280
#define OPENBRACE_TOK 281
#define OPENPAREN_TOK 282
#define PREV_TOK 283
#define PROGRAM_TOK 284
#define PTT_TOK 285
#define REGION_TOK 286
#define RESUME_TOK 287
#define RND_TOK 288
#define ROOT_TOK 289
#define SET_TOK 290
#define SUBTITLE_TOK 291
#define TAIL_TOK 292
#define TITLE_TOK 293
#define TITLESET_TOK 294
#define TOP_TOK 295
#define VMGM_TOK 296
#define BOR_TOK 297
#define LOR_TOK 298
#define XOR_TOK 299
#define _OR_TOK 300
#define BAND_TOK 301
#define LAND_TOK 302
#define _AND_TOK 303
#define NOT_TOK 304
#define NE_TOK 305
#define EQ_TOK 306
#define LT_TOK 307
#define LE_TOK 308
#define GT_TOK 309
#define GE_TOK 310
#define SUB_TOK 311
#define ADD_TOK 312
#define MOD_TOK 313
#define DIV_TOK 314
#define MUL_TOK 315
#define ADDSET_TOK 316
#define SUBSET_TOK 317
#define MULSET_TOK 318
#define DIVSET_TOK 319
#define MODSET_TOK 320
#define ANDSET_TOK 321
#define ORSET_TOK 322
#define XORSET_TOK 323
#define SEMICOLON_TOK 324
#define COLON_TOK 325
#define ERROR_TOK 326




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 89 "dvdvmy.y"
typedef union YYSTYPE {
    unsigned int int_val;
    char *str_val;
    struct vm_statement *statement;
} YYSTYPE;
/* Line 1285 of yacc.c.  */
#line 185 "dvdvmy.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE dvdvmlval;



